<template>
  <example>

  </example>
</template>

<script>
import Example from './components/Example.vue'
  export default {
    components: {Example}
  }
</script>